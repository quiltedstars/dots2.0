# ✨**My Awesomewm Dotfile**✨

_~~little suck~~_

### **Required**
- **_~~[Awesomewm](https://awesomewm.org/)~~_**
- [File Manager](https://wiki.archlinux.org/title/thunar)
- [Discocss](https://github.com/mlvzk/discocss)
- [Rofi](https://github.com/davatorium/rofi)
- [Kitty Term](https://sw.kovidgoyal.net/kitty/)
- [Ibhagwan Forked Picom](https://github.com/ibhagwan/picom)
- [Sarasa Gothic Mono](https://picaq.github.io/sarasa/)

## **[StartPage](https://chocolatebread799.github.io/Startpage/)**


### **Screenshot**
![ex_screenshot](workspace.png)
